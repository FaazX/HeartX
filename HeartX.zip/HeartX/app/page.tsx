"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { HeartScene } from "@/components/heart-scene"
import { Activity } from "lucide-react"

interface FormData {
  age: number
  sex: number
  cp: number
  trestbps: number
  chol: number
  fbs: number
  restecg: number
  thalach: number
  exang: number
  oldpeak: number
  slope: number
  ca: number
  thal: number
}

interface PredictionResult {
  riskCategory: "LOW RISK" | "HIGH RISK"
  riskScore: number
}

export default function HeartXDashboard() {
  const [formData, setFormData] = useState<FormData>({
    age: 50,
    sex: 1,
    cp: 0,
    trestbps: 120,
    chol: 200,
    fbs: 0,
    restecg: 0,
    thalach: 150,
    exang: 0,
    oldpeak: 0,
    slope: 1,
    ca: 0,
    thal: 2,
  })

  const [prediction, setPrediction] = useState<PredictionResult | null>(null)
  const [triggerRiskAnimation, setTriggerRiskAnimation] = useState(false)

  const handleSliderChange = (field: keyof FormData, value: number[]) => {
    setFormData((prev) => ({ ...prev, [field]: value[0] }))
  }

  const calculateRisk = () => {
    let riskScore = 0

    riskScore += ((formData.age - 29) / (77 - 29)) * 0.15
    riskScore += formData.cp === 3 ? 0.15 : formData.cp * 0.05
    riskScore += ((formData.trestbps - 94) / (200 - 94)) * 0.1
    riskScore += ((formData.chol - 126) / (564 - 126)) * 0.15
    riskScore += ((202 - formData.thalach) / (202 - 71)) * 0.1
    riskScore += formData.exang * 0.15
    riskScore += (formData.oldpeak / 6.2) * 0.1
    riskScore += (formData.ca / 4) * 0.1
    riskScore += formData.thal === 3 ? 0.1 : 0

    riskScore = Math.min(Math.max(riskScore, 0), 1)

    setPrediction({
      riskCategory: riskScore >= 0.5 ? "HIGH RISK" : "LOW RISK",
      riskScore: riskScore,
    })

    setTriggerRiskAnimation(true)
    setTimeout(() => setTriggerRiskAnimation(false), 100)
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-black">
      <div className="w-[80%] relative">
        <HeartScene
          riskScore={prediction?.riskScore ?? 0}
          age={formData.age}
          cholesterol={formData.chol}
          bloodPressure={formData.trestbps}
          chestPain={formData.cp}
          stDepression={formData.oldpeak}
          majorVessels={formData.ca}
          exerciseAngina={formData.exang}
          riskCategory={prediction?.riskCategory}
          triggerAnimation={triggerRiskAnimation}
        />
      </div>

      <div className="w-[20%] bg-black/95 backdrop-blur-xl p-6 overflow-y-auto border-l border-white/10 flex flex-col">
        <div className="space-y-6 flex-1">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-red-500/20 mb-3 shadow-[0_0_30px_rgba(239,68,68,0.5)]">
              <Activity className="w-6 h-6 text-red-500" />
            </div>
            <h1 className="text-2xl font-light text-white tracking-wider">HeartX</h1>
            <p className="text-xs text-white/50 font-light">Risk Assessment</p>
          </div>

          {prediction && (
            <Card
              className={`bg-white/5 border-white/10 p-4 backdrop-blur-sm ${
                prediction.riskCategory === "LOW RISK"
                  ? "shadow-[0_0_40px_rgba(74,222,128,0.4)]"
                  : "shadow-[0_0_40px_rgba(239,68,68,0.3)]"
              }`}
            >
              <div className="text-center space-y-2">
                <p className="text-xs text-white/50 uppercase tracking-widest font-light">Result</p>
                <h2
                  className={`text-2xl font-light tracking-wide ${
                    prediction.riskCategory === "LOW RISK"
                      ? "text-green-400 drop-shadow-[0_0_20px_rgba(74,222,128,0.8)]"
                      : "text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]"
                  }`}
                >
                  {prediction.riskCategory}
                </h2>
                <p className="text-xl text-white/90 font-light">{(prediction.riskScore * 100).toFixed(0)}%</p>
              </div>
            </Card>
          )}

          <div className="space-y-5">
            {/* Age */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Age</Label>
                <span className="text-white font-light text-sm">{formData.age}</span>
              </div>
              <Slider
                value={[formData.age]}
                onValueChange={(v) => handleSliderChange("age", v)}
                min={29}
                max={77}
                step={1}
                className="cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 font-light text-xs">Gender</Label>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="male"
                    checked={formData.sex === 1}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, sex: checked ? 1 : 0 }))}
                    className="border-white/30 data-[state=checked]:bg-red-500/50 data-[state=checked]:border-red-500"
                  />
                  <label htmlFor="male" className="text-white/70 font-light text-xs cursor-pointer">
                    Male
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="female"
                    checked={formData.sex === 0}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, sex: checked ? 0 : 1 }))}
                    className="border-white/30 data-[state=checked]:bg-red-500/50 data-[state=checked]:border-red-500"
                  />
                  <label htmlFor="female" className="text-white/70 font-light text-xs cursor-pointer">
                    Female
                  </label>
                </div>
              </div>
            </div>

            {/* Blood Pressure */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Blood Pressure</Label>
                <span className="text-white font-light text-sm">{formData.trestbps}</span>
              </div>
              <Slider
                value={[formData.trestbps]}
                onValueChange={(v) => handleSliderChange("trestbps", v)}
                min={94}
                max={200}
                step={1}
                className="cursor-pointer"
              />
            </div>

            {/* Cholesterol */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Cholesterol</Label>
                <span className="text-white font-light text-sm">{formData.chol}</span>
              </div>
              <Slider
                value={[formData.chol]}
                onValueChange={(v) => handleSliderChange("chol", v)}
                min={126}
                max={564}
                step={1}
                className="cursor-pointer"
              />
            </div>

            {/* Max Heart Rate */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Max Heart Rate</Label>
                <span className="text-white font-light text-sm">{formData.thalach}</span>
              </div>
              <Slider
                value={[formData.thalach]}
                onValueChange={(v) => handleSliderChange("thalach", v)}
                min={71}
                max={202}
                step={1}
                className="cursor-pointer"
              />
            </div>

            {/* Chest Pain Type */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Chest Pain</Label>
                <span className="text-white font-light text-sm">{formData.cp}</span>
              </div>
              <Slider
                value={[formData.cp]}
                onValueChange={(v) => handleSliderChange("cp", v)}
                min={0}
                max={3}
                step={1}
                className="cursor-pointer"
              />
            </div>

            {/* Exercise Angina */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Exercise Angina</Label>
                <span className="text-white font-light text-sm">{formData.exang === 1 ? "Yes" : "No"}</span>
              </div>
              <Slider
                value={[formData.exang]}
                onValueChange={(v) => handleSliderChange("exang", v)}
                min={0}
                max={1}
                step={1}
                className="cursor-pointer"
              />
            </div>

            {/* ST Depression */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">ST Depression</Label>
                <span className="text-white font-light text-sm">{formData.oldpeak.toFixed(1)}</span>
              </div>
              <Slider
                value={[formData.oldpeak]}
                onValueChange={(v) => handleSliderChange("oldpeak", v)}
                min={0}
                max={6.2}
                step={0.1}
                className="cursor-pointer"
              />
            </div>

            {/* Major Vessels */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white/70 font-light text-xs">Major Vessels</Label>
                <span className="text-white font-light text-sm">{formData.ca}</span>
              </div>
              <Slider
                value={[formData.ca]}
                onValueChange={(v) => handleSliderChange("ca", v)}
                min={0}
                max={4}
                step={1}
                className="cursor-pointer"
              />
            </div>

            <Button
              onClick={calculateRisk}
              className="w-full bg-red-500/20 hover:bg-red-500/30 text-white font-light text-sm py-5 border border-red-500/50 shadow-[0_0_30px_rgba(239,68,68,0.3)] hover:shadow-[0_0_40px_rgba(239,68,68,0.5)] transition-all duration-300"
            >
              Calculate Risk
            </Button>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-white/10 text-center">
          <p className="text-white/30 text-xs font-light tracking-widest">Faaz</p>
        </div>
      </div>
    </div>
  )
}
