"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Environment, Html, useGLTF } from "@react-three/drei"
import { useRef, useEffect, useState } from "react"
import * as THREE from "three"

interface HeartModelProps {
  riskScore: number
  riskCategory?: "LOW RISK" | "HIGH RISK"
  triggerAnimation: boolean
}

function HeartModel({ riskScore, riskCategory, triggerAnimation }: HeartModelProps) {
  const { scene } = useGLTF("/heart.glb")
  const heartRef = useRef<THREE.Group>(null)
  const [animationProgress, setAnimationProgress] = useState(0)
  const originalMaterialsRef = useRef<Map<THREE.Mesh, THREE.Material>>(new Map())

  useEffect(() => {
    if (heartRef.current && originalMaterialsRef.current.size === 0) {
      heartRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material) {
          originalMaterialsRef.current.set(child, child.material.clone())
        }
      })
    }
  }, [])

  useEffect(() => {
    if (triggerAnimation && riskCategory) {
      setAnimationProgress(0)
      const duration = 2000
      const startTime = Date.now()

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)

        if (progress < 0.5) {
          setAnimationProgress(progress * 2)
        } else {
          setAnimationProgress(2 - progress * 2)
        }

        if (progress < 1) {
          requestAnimationFrame(animate)
        } else {
          setAnimationProgress(0)
        }
      }

      requestAnimationFrame(animate)
    }
  }, [triggerAnimation, riskCategory])

  useEffect(() => {
    if (heartRef.current) {
      heartRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material) {
          const material = child.material as THREE.MeshStandardMaterial

          let colorMultiplier: THREE.Color
          let emissiveColor: THREE.Color

          if (animationProgress > 0) {
            if (riskCategory === "LOW RISK") {
              colorMultiplier = new THREE.Color().lerpColors(
                new THREE.Color(1, 1, 1),
                new THREE.Color(0.3, 1.5, 0.3),
                animationProgress,
              )
              emissiveColor = new THREE.Color().lerpColors(
                new THREE.Color(0, 0, 0),
                new THREE.Color(0, 0.3, 0),
                animationProgress,
              )
            } else {
              colorMultiplier = new THREE.Color().lerpColors(
                new THREE.Color(1, 1, 1),
                new THREE.Color(1.5, 0.3, 0.3),
                animationProgress,
              )
              emissiveColor = new THREE.Color().lerpColors(
                new THREE.Color(0, 0, 0),
                new THREE.Color(0.5, 0, 0),
                animationProgress,
              )
            }
          } else {
            colorMultiplier = riskScore >= 0.5 ? new THREE.Color(1.2, 0.8, 0.8) : new THREE.Color(1, 1, 1)
            emissiveColor = riskScore >= 0.5 ? new THREE.Color(0.3, 0, 0) : new THREE.Color(0, 0, 0)
          }

          // Preserve original material properties and textures
          if (material.color) {
            const originalMaterial = originalMaterialsRef.current.get(child) as THREE.MeshStandardMaterial
            if (originalMaterial && originalMaterial.color) {
              material.color.copy(originalMaterial.color).multiply(colorMultiplier)
            }
          }

          material.emissive = emissiveColor
          material.emissiveIntensity = animationProgress > 0 ? 0.5 : riskScore >= 0.5 ? riskScore * 0.8 : 0.1
        }
      })
    }
  }, [riskScore, animationProgress, riskCategory])

  useEffect(() => {
    if (!heartRef.current) return

    const baseSpeed = riskScore >= 0.5 ? 2.5 : 1.5
    let time = 0

    const animate = () => {
      time += 0.016 * baseSpeed
      const scale = 1 + Math.sin(time * 3) * 0.05
      if (heartRef.current) {
        heartRef.current.scale.set(scale, scale, scale)
      }
      requestAnimationFrame(animate)
    }

    const animationId = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(animationId)
  }, [riskScore])

  return (
    <group ref={heartRef} position={[-1, -2, 1]}>
      <primitive object={scene} scale={0.15} rotation={[0, Math.PI / 2, 0]} />
    </group>
  )
}

interface DataLabelProps {
  position: [number, number, number]
  label: string
  value: string | number
}

function DataLabel({ position, label, value }: DataLabelProps) {
  return (
    <Html position={position} center>
      <div className="bg-black/80 backdrop-blur-sm border border-white/20 rounded-lg px-3 py-1.5 text-white pointer-events-none shadow-[0_0_20px_rgba(0,0,0,0.5)]">
        <div className="text-[10px] text-white/50 uppercase tracking-widest font-light">{label}</div>
        <div className="text-lg font-light">{value}</div>
      </div>
    </Html>
  )
}

function Starfield({ riskCategory, triggerAnimation }: { riskCategory?: string; triggerAnimation: boolean }) {
  const starsRef = useRef<THREE.Points>(null)
  const [bgColor, setBgColor] = useState<THREE.Color>(new THREE.Color(0, 0, 0))

  useEffect(() => {
    if (triggerAnimation && riskCategory) {
      const duration = 2000
      const startTime = Date.now()

      const animate = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)

        let targetColor: THREE.Color
        if (riskCategory === "LOW RISK") {
          targetColor = new THREE.Color(0, 0.08, 0) // Slightly green
        } else {
          targetColor = new THREE.Color(0.08, 0, 0) // Slightly red
        }

        const baseColor = new THREE.Color(0, 0, 0)

        if (progress < 0.5) {
          setBgColor(new THREE.Color().lerpColors(baseColor, targetColor, progress * 2))
        } else {
          setBgColor(new THREE.Color().lerpColors(targetColor, baseColor, (progress - 0.5) * 2))
        }

        if (progress < 1) {
          requestAnimationFrame(animate)
        } else {
          setBgColor(baseColor)
        }
      }

      requestAnimationFrame(animate)
    }
  }, [triggerAnimation, riskCategory])

  useEffect(() => {
    const starCount = 2000
    const positions = new Float32Array(starCount * 3)

    for (let i = 0; i < starCount * 3; i += 3) {
      const radius = 20 + Math.random() * 30
      const theta = Math.random() * Math.PI * 2
      const phi = Math.random() * Math.PI

      positions[i] = radius * Math.sin(phi) * Math.cos(theta)
      positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta)
      positions[i + 2] = radius * Math.cos(phi)
    }

    if (starsRef.current) {
      starsRef.current.geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3))
    }
  }, [])

  useEffect(() => {
    if (!starsRef.current) return

    const animate = () => {
      if (starsRef.current && starsRef.current.material) {
        const material = starsRef.current.material as THREE.PointsMaterial
        material.opacity = 0.5 + Math.sin(Date.now() * 0.001) * 0.3
      }
      requestAnimationFrame(animate)
    }

    const animationId = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(animationId)
  }, [])

  return (
    <>
      <color attach="background" args={[bgColor.r, bgColor.g, bgColor.b]} />
      <points ref={starsRef}>
        <bufferGeometry />
        <pointsMaterial size={0.15} color="#ffffff" transparent opacity={0.8} sizeAttenuation />
      </points>
    </>
  )
}

interface HeartSceneProps {
  riskScore: number
  age: number
  cholesterol: number
  bloodPressure: number
  chestPain: number
  stDepression: number
  majorVessels: number
  exerciseAngina: number
  riskCategory?: "LOW RISK" | "HIGH RISK"
  triggerAnimation: boolean
}

export function HeartScene({
  riskScore,
  age,
  cholesterol,
  bloodPressure,
  chestPain,
  stDepression,
  majorVessels,
  exerciseAngina,
  riskCategory,
  triggerAnimation,
}: HeartSceneProps) {
  return (
    <Canvas camera={{ position: [2, 0, 0], fov: 50 }} gl={{ antialias: true, alpha: true }}>
      <Starfield riskCategory={riskCategory} triggerAnimation={triggerAnimation} />

      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={1.2} castShadow />
      <directionalLight position={[-5, -5, -5]} intensity={0.6} />
      <pointLight position={[0, 0, 5]} intensity={1} color="#ff3333" />

      <Environment preset="city" />

      <HeartModel riskScore={riskScore} riskCategory={riskCategory} triggerAnimation={triggerAnimation} />

      {riskScore > 0 && (
        <>
          <DataLabel position={[-1.6, -1.5, 1.3]} label="Age" value={`${age} yrs`} />
          <DataLabel position={[-0.4, -1.4, 1.4]} label="Cholesterol" value={`${cholesterol} mg/dl`} />
          <DataLabel position={[-1.5, -2.5, 0.7]} label="Blood Pressure" value={`${bloodPressure} mmHg`} />
          <DataLabel position={[-0.5, -2.4, 0.6]} label="Chest Pain" value={chestPain} />
          <DataLabel position={[-1.7, -2.0, 1.5]} label="ST Depression" value={stDepression.toFixed(1)} />
          <DataLabel position={[-0.3, -2.1, 0.8]} label="Major Vessels" value={majorVessels} />
          <DataLabel position={[-1.0, -2.8, 1.0]} label="Exercise Angina" value={exerciseAngina === 1 ? "Yes" : "No"} />
        </>
      )}

      <OrbitControls enableZoom={true} enablePan={true} minDistance={1} maxDistance={10} target={[0, 0, 0]} />
    </Canvas>
  )
}

useGLTF.preload("/heart.glb")
